import { $, component$, useSignal } from "@builder.io/qwik";
import {
  Link,
  RequestEventBase,
  routeLoader$,
  server$,
  useNavigate,
  type DocumentHead,
} from "@builder.io/qwik-city";
import { eq } from "drizzle-orm/pg-core/expressions";
import { animals, uniqueNamesGenerator } from "unique-names-generator";

import Button from "../components/common/button";
import { db } from "../db/db";
import { anonymousUsers, users } from "../db/schema";
import { createRoom } from "../server/game-service";
import { rollDice } from "../server/secure-random";
import { title } from "../utils/title";

const getSessionId = (requestEvent: RequestEventBase) => {
  const existingCookie = requestEvent.cookie.get("sessionId");
  if (existingCookie) {
    return existingCookie.value;
  }
  const sessionId = crypto.randomUUID();
  requestEvent.cookie.set("sessionId", sessionId, {
    httpOnly: true,
    sameSite: "strict",
  });
  return sessionId;
};

export const useAnonymousUserName = routeLoader$(async (requestEvent): Promise<{ name: string; sessionId: string }> => {
  const sessionId = getSessionId(requestEvent);
  const user = await db.query.users.findFirst({
    where: eq(users.id, sessionId),
  });
  if (user) {
    return { name: user.displayName ?? "Unknown", sessionId };
  }
  const anonymousUser = await db.query.anonymousUsers.findFirst({
    where: eq(anonymousUsers.id, sessionId),
  });
  if (anonymousUser) {
    return { name: anonymousUser.name, sessionId };
  }
  const name = uniqueNamesGenerator({ dictionaries: [animals] });
  await db.insert(anonymousUsers).values({ id: sessionId, name });
  return { name, sessionId };
});

export const serverRollDice = server$(async () => {
  const [firstNumber, secondNumber] = rollDice(2, 6);
  return `${firstNumber},${secondNumber}`;
});

const createRoomAction = server$(async (hostId: string) => await createRoom(hostId));

export default component$(() => {
  const { name, sessionId } = useAnonymousUserName().value;
  const nav = useNavigate();
  const isLoading = useSignal(false);
  const createRoom = $(async () => {
    try {
      isLoading.value = true;
      const code = await createRoomAction(sessionId);
      await nav(`/room/${code}/`);
    } finally {
      isLoading.value = false;
    }
  });

  return (
    <>
    <div class="absolute right-4 top-4 capitalize text-xl select-none">
      <p>👤 Anonymous {name}</p>
    </div>
    <div class="flex h-full flex-col items-center justify-center gap-4 select-none">
      <h1 class="text-8xl font-bold">{title}</h1>
      <p class="text-xl">Roll your dice, earn coins, and expand your town!</p>
      <div class="grid grid-cols-2 items-center justify-center gap-4 w-100">
        <Button onClick$={createRoom} isLoading={isLoading.value}>Create Game</Button>
        <Link href="/room/join/">
          <Button>Join Game</Button>
        </Link>
        <Link class="col-span-2">
          <Button variant="secondary">How to play</Button>
        </Link>
      </div>
    </div>
    </>
  );
});

export const head: DocumentHead = {
  title: `Welcome`,
  meta: [
    {
      name: "description",
      content: `${title} is a game about rolling dice and building towns.`,
    },
  ],
};
