import DiceBox from "@3d-dice/dice-box-threejs";

declare global {
  var diceBox: DiceBox | undefined;
}

export {};
