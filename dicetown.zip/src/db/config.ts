export const dbUrl = process.env.DATABASE_URL ?? "";
